#ifndef __PRINT_H
#define __PRINT_H

void printchar(unsigned char* toPrint,int printLength, char* message);


#endif

